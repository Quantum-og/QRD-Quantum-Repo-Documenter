import React, { useMemo } from 'react';
import {
  Box, List, ListItem, ListItemButton, ListItemIcon, ListItemText,
  Typography, Chip, useTheme, alpha,
} from '@mui/material';
import {
  Folder, FolderOpen, InsertDriveFile, Code, DataObject,
  Image, Description, BubbleChart,
} from '@mui/icons-material';
import { SimpleTreeView, TreeItem } from '@mui/x-tree-view';

interface FileNode {
  id: string; name: string; type: 'file' | 'directory';
  relative_path: string; path: string; extension?: string;
  language?: string; line_count?: number; size?: number;
  children?: FileNode[];
}

interface Props {
  fileTree: FileNode | null;
  flatFiles: FileNode[];
  searchQuery: string;
  viewMode: 'tree' | 'list';
  onFileSelect: (path: string) => void;
  selectedPath: string | null;
}

function getFileIcon(node: FileNode) {
  if (node.type === 'directory') return <Folder fontSize="small" />;
  const ext = node.extension || '';
  if (['.py', '.js', '.ts', '.tsx', '.sh', '.sql'].includes(ext)) return <Code fontSize="small" color="primary" />;
  if (['.json', '.yaml', '.yml', '.toml'].includes(ext)) return <DataObject fontSize="small" color="secondary" />;
  if (['.png', '.jpg', '.svg', '.webp'].includes(ext)) return <Image fontSize="small" color="success" />;
  if (['.md', '.txt', '.pdf'].includes(ext)) return <Description fontSize="small" color="action" />;
  if (['.las', '.dlis'].includes(ext)) return <BubbleChart fontSize="small" color="warning" />;
  return <InsertDriveFile fontSize="small" color="action" />;
}

export const FileTreeView: React.FC<Props> = ({
  fileTree, flatFiles, searchQuery, viewMode, onFileSelect, selectedPath,
}) => {
  const theme = useTheme();

  const filteredFiles = useMemo(() => {
    if (!searchQuery) return flatFiles;
    const q = searchQuery.toLowerCase();
    return flatFiles.filter((f) => f.name.toLowerCase().includes(q) || f.relative_path.toLowerCase().includes(q));
  }, [flatFiles, searchQuery]);

  const renderTreeNode = (node: FileNode): React.ReactNode => (
    <TreeItem
      key={node.id || node.path}
      itemId={node.id || node.path}
      label={
        <Box
          sx={{ display: 'flex', alignItems: 'center', gap: 0.75, py: 0.3 }}
          onClick={() => node.type === 'file' && onFileSelect(node.path)}
        >
          {getFileIcon(node)}
          <Typography
            variant="body2"
            noWrap
            sx={{ fontWeight: node.type === 'directory' ? 600 : 400, fontSize: 13 }}
          >
            {node.name}
          </Typography>
          {node.type === 'file' && node.line_count && (
            <Typography variant="caption" color="text.disabled" sx={{ ml: 'auto', flexShrink: 0 }}>
              {node.line_count.toLocaleString()}L
            </Typography>
          )}
        </Box>
      }
    >
      {node.children?.map(renderTreeNode)}
    </TreeItem>
  );

  if (viewMode === 'list' || searchQuery) {
    return (
      <List dense disablePadding>
        {filteredFiles.map((f) => (
          <ListItem key={f.id} disablePadding>
            <ListItemButton
              selected={f.path === selectedPath}
              onClick={() => onFileSelect(f.path)}
              sx={{
                py: 0.5, px: 1.5,
                '&.Mui-selected': { bgcolor: alpha(theme.palette.primary.main, 0.1) },
              }}
            >
              <ListItemIcon sx={{ minWidth: 28 }}>{getFileIcon(f)}</ListItemIcon>
              <ListItemText
                primary={f.name}
                secondary={f.relative_path}
                primaryTypographyProps={{ variant: 'body2', noWrap: true }}
                secondaryTypographyProps={{ variant: 'caption', noWrap: true }}
              />
              {f.line_count && (
                <Typography variant="caption" color="text.disabled">
                  {f.line_count.toLocaleString()}L
                </Typography>
              )}
            </ListItemButton>
          </ListItem>
        ))}
        {filteredFiles.length === 0 && (
          <Box sx={{ p: 3, textAlign: 'center' }}>
            <Typography variant="body2" color="text.secondary">No files match</Typography>
          </Box>
        )}
      </List>
    );
  }

  return (
    <SimpleTreeView sx={{ p: 1 }}>
      {fileTree ? renderTreeNode(fileTree) : (
        <Typography variant="body2" color="text.secondary" sx={{ p: 2 }}>
          No files loaded
        </Typography>
      )}
    </SimpleTreeView>
  );
};
