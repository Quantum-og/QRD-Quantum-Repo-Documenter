#!/usr/bin/env bash
# ─── RepoDoc Pro — Backend Development Setup ─────────────────────────────────
# Run from the backend/ directory: bash scripts/setup_dev.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$(dirname "$SCRIPT_DIR")"

echo "🔧 Setting up RepoDoc Pro backend..."
cd "$BACKEND_DIR"

# 1. Check Python version
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
MAJOR=$(echo "$PYTHON_VERSION" | cut -d. -f1)
MINOR=$(echo "$PYTHON_VERSION" | cut -d. -f2)

if [ "$MAJOR" -lt 3 ] || { [ "$MAJOR" -eq 3 ] && [ "$MINOR" -lt 10 ]; }; then
  echo "❌ Python 3.10+ required. Found: $PYTHON_VERSION"
  exit 1
fi
echo "✅ Python $PYTHON_VERSION"

# 2. Create virtual environment
if [ ! -d ".venv" ]; then
  echo "📦 Creating virtual environment..."
  python3 -m venv .venv
fi

# 3. Activate
source .venv/bin/activate
echo "✅ Virtual environment activated"

# 4. Install system dependencies (Linux/macOS)
if [ "$(uname)" = "Linux" ]; then
  echo "🔧 Installing system dependencies..."
  sudo apt-get update -qq
  sudo apt-get install -y -qq \
    libpango-1.0-0 libpangocairo-1.0-0 libcairo2 \
    libgdk-pixbuf2.0-0 libffi-dev fonts-liberation \
    2>/dev/null || echo "⚠️  Could not install system deps (may need sudo)"
elif [ "$(uname)" = "Darwin" ]; then
  if command -v brew &>/dev/null; then
    brew install pango cairo libffi 2>/dev/null || true
  fi
fi

# 5. Install Python packages
echo "📦 Installing Python packages..."
pip install --upgrade pip -q
pip install -r requirements.txt -q
echo "✅ Python packages installed"

# 6. Create .env if not exists
if [ ! -f ".env" ]; then
  cat > .env << 'EOF'
# RepoDoc Pro Backend — Environment Configuration
REPODOC_ENV=development
REPODOC_PORT=8765
REPODOC_LOG_LEVEL=DEBUG
REPODOC_TEMP_DIR=/tmp/repodoc

# AI Documentation (optional)
# ANTHROPIC_API_KEY=sk-ant-...
# OPENAI_API_KEY=sk-...
EOF
  echo "✅ Created .env (fill in API keys for AI features)"
fi

# 7. Run tests
echo "🧪 Running tests..."
pytest tests/ -x -q --no-header 2>&1 | tail -20 || echo "⚠️  Some tests failed"

echo ""
echo "🚀 Setup complete! Start the backend with:"
echo "   source .venv/bin/activate"
echo "   python src/main.py --port 8765 --reload"
