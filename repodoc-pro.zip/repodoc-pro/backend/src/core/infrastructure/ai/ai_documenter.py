"""
AI Documenter — Generates structured documentation for source files
using the Anthropic Claude API (or OpenAI as fallback).
"""

from __future__ import annotations

import json
import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are a senior software engineer generating structured technical documentation.
Analyze the provided source code and return ONLY valid JSON (no markdown, no explanation).

Return this exact JSON structure:
{
  "summary": "One-sentence description of what this file does",
  "purpose": "2-3 sentence explanation of the file's role in the project",
  "key_functions": ["function or class name: what it does", ...],
  "inputs": ["description of inputs/parameters/arguments", ...],
  "outputs": ["description of return values/outputs/side effects", ...],
  "dependencies": ["package or module name", ...],
  "complexity": "Low|Medium|High|Very High",
  "notes": "Any important notes about design decisions, gotchas, or patterns used"
}"""


class AIDocumenter:
    """
    Generates AI documentation for source files.

    Supports:
    - Anthropic Claude (primary)
    - OpenAI GPT-4 (fallback)
    - Offline stub mode (when no API key is configured)
    """

    def __init__(self, settings) -> None:
        self._settings = settings
        self._client = None
        self._provider = "none"
        self._setup_client()

    def _setup_client(self) -> None:
        """Initialize the AI client based on available API keys."""
        if self._settings.anthropic_api_key:
            try:
                import anthropic
                self._client = anthropic.AsyncAnthropic(
                    api_key=self._settings.anthropic_api_key
                )
                self._provider = "anthropic"
                logger.info("AI provider: Anthropic Claude")
            except ImportError:
                logger.warning("anthropic package not installed")

        elif self._settings.openai_api_key:
            try:
                import openai
                self._client = openai.AsyncOpenAI(
                    api_key=self._settings.openai_api_key
                )
                self._provider = "openai"
                logger.info("AI provider: OpenAI")
            except ImportError:
                logger.warning("openai package not installed")
        else:
            logger.info("No AI API key configured — using stub documentation")

    async def document_file(
        self,
        file_path: str,
        content: str,
        language: str,
        max_content_chars: int = 8000,
    ) -> dict:
        """
        Generate documentation for a source file.

        Returns a dict with: summary, purpose, key_functions,
        inputs, outputs, dependencies, complexity, notes.
        """
        if not self._client or self._provider == "none":
            return self._stub_documentation(file_path, language)

        # Truncate very large files
        truncated_content = content[:max_content_chars]
        if len(content) > max_content_chars:
            truncated_content += f"\n\n... [truncated at {max_content_chars} chars]"

        user_message = (
            f"File: {file_path}\n"
            f"Language: {language}\n\n"
            f"```{language}\n{truncated_content}\n```"
        )

        try:
            if self._provider == "anthropic":
                return await self._call_anthropic(user_message)
            elif self._provider == "openai":
                return await self._call_openai(user_message)
        except Exception as e:
            logger.warning(f"AI documentation failed for {file_path}: {e}")
            return self._stub_documentation(file_path, language)

        return self._stub_documentation(file_path, language)

    async def _call_anthropic(self, user_message: str) -> dict:
        """Call Anthropic Claude API."""
        response = await self._client.messages.create(
            model=self._settings.ai_model,
            max_tokens=1024,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_message}],
        )
        raw = response.content[0].text
        return self._parse_json_response(raw)

    async def _call_openai(self, user_message: str) -> dict:
        """Call OpenAI API."""
        response = await self._client.chat.completions.create(
            model="gpt-4o-mini",
            max_tokens=1024,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_message},
            ],
            response_format={"type": "json_object"},
        )
        raw = response.choices[0].message.content or "{}"
        return self._parse_json_response(raw)

    @staticmethod
    def _parse_json_response(raw: str) -> dict:
        """Parse JSON from AI response, handling common formatting issues."""
        # Strip markdown code fences if present
        cleaned = re.sub(r"```(?:json)?\n?", "", raw).strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            logger.warning(f"Could not parse AI JSON response: {cleaned[:200]}")
            return {
                "summary": "Documentation could not be parsed",
                "purpose": "",
                "key_functions": [],
                "inputs": [],
                "outputs": [],
                "dependencies": [],
                "complexity": "Unknown",
                "notes": raw[:500],
            }

    @staticmethod
    def _stub_documentation(file_path: str, language: str) -> dict:
        """Return a placeholder when AI is unavailable."""
        return {
            "summary": f"Source file: {file_path.split('/')[-1]}",
            "purpose": "AI documentation is not configured. Add ANTHROPIC_API_KEY or OPENAI_API_KEY to enable.",
            "key_functions": [],
            "inputs": [],
            "outputs": [],
            "dependencies": [],
            "complexity": "Unknown",
            "notes": f"Language: {language}",
        }
