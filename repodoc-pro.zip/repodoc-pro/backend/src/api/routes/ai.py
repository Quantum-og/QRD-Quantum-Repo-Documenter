"""AI Documentation Route"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from utils.config import Settings
from core.infrastructure.ai.ai_documenter import AIDocumenter

router = APIRouter()
settings = Settings()
_documenter = AIDocumenter(settings)

class AIDocRequest(BaseModel):
    file_path: str
    content: str
    language: str

@router.post("/document")
async def document_file(req: AIDocRequest) -> dict:
    return await _documenter.document_file(req.file_path, req.content, req.language)

@router.get("/status")
async def ai_status() -> dict:
    return {
        "enabled": settings.ai_enabled,
        "model": settings.ai_model,
        "has_anthropic_key": bool(settings.anthropic_api_key),
        "has_openai_key": bool(settings.openai_api_key),
    }
